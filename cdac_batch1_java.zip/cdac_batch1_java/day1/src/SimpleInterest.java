import java.util.Scanner;
public class SimpleInterest{
 
  public static void main(String[] args){
  int p,r,t;
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter Priciple Rate Time");
  p = sc.nextInt();
  r = sc.nextInt();
  t = sc.nextInt();
  int choice;
System.out.println("Press 1 for-> Simple Interest Press 2 -> Compound Interest");
System.out.println("Enter the Choice");


choice = sc.nextInt();
switch(choice){
  case 1:
        System.out.println("Simple Interest - >"+(p*r*t/100));
        break;
  case 2:
       System.out.println("Simple Interest - >" +( p * (Math.pow((1 + r / 100), t)) - p));
        break;

    


  

}
}
}