import java.util.Scanner;

public class SumDigit{


public int sum(int digit)
{
int sum=0;
int temp=digit;
while(temp>0)
{
sum+=temp%10;
temp=temp/10;
}
return sum;

}


public static void main(String[] args)
{

int number;

Scanner sc =new Scanner(System.in);
System.out.println("Enter Digit");

number=sc.nextInt();

SumDigit D=new SumDigit();

System.out.println(D.sum(number));




}
}
