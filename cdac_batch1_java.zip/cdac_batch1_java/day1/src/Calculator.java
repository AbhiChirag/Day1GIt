import java.util.Scanner;
public class Calculator{
 public static void main(String[] args){
  int a,b;
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter the No.");
  a = sc.nextInt();
System.out.println("Enter the No.");
  b = sc.nextInt();
 
int choice;
System.out.println("Press 1 for-> ADDITION Press 2 -> Substraction Press 3 for -> Multiplication");
System.out.println("Enter the Choice");


choice = sc.nextInt();
switch(choice)
{
case 1:
        System.out.println("Addition of Two number ->"+(a+b));
        break;
case 2:
       System.out.println("Difference between the two numbers: "+(a-b));
       break;
case 3:
       System.out.println("Difference between the two numbers: ");
      break;
}
}
}